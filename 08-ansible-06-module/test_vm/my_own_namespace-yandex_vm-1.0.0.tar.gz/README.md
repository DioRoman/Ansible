# Ansible Collection - my_own_namespace.yandex_vm

Documentation for the collection.
